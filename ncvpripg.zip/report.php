<!DOCTYPE html>
<html>
<?php
error_reporting(-1);?>
<head>

<style>
th, td {
    padding: 5px;
    text-align: left;
	}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color:#fff;
}
table#t01 th	{
    background-color: black;
    color: white;
}
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style2 {font-size: 24px}
.style3 {font-size: 18px}
</style>
<style media="screen">
  .noPrint{ visibility: visibile; }
  .yesPrint{ visibility: visibile;!important; }
</style> 
<style media="print">
  .noPrint{ display: none; }
  .yesPrint{ visibility: visibile; !important; }
</style>
</head>
</head>
<body>

<?php
include('config.php');
//$type= sanGetParam( $_REQUEST, 'type', '');
$sql = "SELECT * from tnde";
$result=mysql_query($sql);
?>
<center>
 <p><strong><span class="title-bar-maroon">DEPARTMENT OF MATHAMATICS </span></strong><br>
   <strong>Theory and Numerics of Differential Equations <br />
    <!--<span style="color: #021441;">December 4 - 13, 2019</span></strong><br>-->
</p>

<table id="t01" width="100%">
<tr >
<th class='noPrint'>Sl.No.</th>
<th class='yesPrint'>Reg.No.</th>
<th class='noPrint'>Name</th>
<th class='yesPrint'>Gender</th>
<th class='noPrint'>Category</th>
<th class='yesPrint'>Designation</th>
<th class='yesPrint'>Official Address State</th>
<th class='yesPrint'>Name Of Institute</th>
<th class='yesPrint'>District</th>
<th class='yesPrint'>State </th>
<th class='yesPrint'>Phone No.</th>
<th class='yesPrint'>Email </th>
<th class='yesPrint'>Area Of Research </th>

</tr>
<tr>
<?php
	$j = 2;
	$i=1;
	 while($row = mysql_fetch_array($result)) 
	 {
	 	
		echo "<td class='yesPrint'>".$i++."</td>";
		echo "<td class='yesPrint'>".$row["Regno"]."</td>";
		echo "<td class='yesPrint'>".$row["Title"].".&nbsp;".$row["Name"]."</td>";
		echo "<td class='yesPrint'>".$row["Gender"]."</td>";
		echo "<td class='yesPrint'>".$row["Category1"]."</td>";
		echo "<td class='yesPrint'>".$row["Designation"]."</td>";
		echo "<td class='yesPrint'>".$row["Official_adress"]."</td>";
		echo "<td class='yesPrint'>".$row["Institute"]."</td>";
		echo "<td class='yesPrint'>".$row["District"]."</td>";
		echo "<td class='yesPrint'>".$row["State"]."</td>";
		echo "<td class='yesPrint'>".$row["Phone_no"]."</td>";
		echo "<td class='yesPrint'>".$row["Email"]."</td>";
		echo "<td class='yesPrint'>".$row["Area_research"]."</td>";
		//echo "<td class='yesPrint'>".$areain."</td>";
		//echo "<td class='yesPrint'>".$row["Abs_year"]."</td>";
		//echo "<td class='yesPrint'><a target='_blank' href='abstracts/".$row["File_name"]."'>View</a></td>";
		echo "</tr>";
	 }

?> 


<!--<tr>
<td><input type="button" 
          value="Print" class="noPrint" onClick="window.print();"></td>

</tr>-->



 </table>
 </form>
</center>

</body>
</html>