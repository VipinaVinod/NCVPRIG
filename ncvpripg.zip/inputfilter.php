<?php
require_once( 'phpInputFilter/class.inputfilter.php' );
header("X-Frame-Options: DENY");
header("Content-Security-Policy: frame-ancestors 'none'", false);
define( "_AR_NOTRIM", 0x0001 );
define( "_AR_ALLOWHTML", 0x0002 );
define( "_AR_ALLOWRAW", 0x0004 );
function sanGetParam( &$arr, $name, $def=null, $mask=0 ) {
	static $noHtmlFilter 	= null;
	static $safeHtmlFilter 	= null;

	$return = null;
	if (isset( $arr[$name] )) {
		$return = $arr[$name];
		
		if (is_string( $return )) {
			// trim data
			if (!($mask&_AR_NOTRIM)) {
				$return = trim( $return );
			}
			
			if ($mask&_AR_ALLOWRAW) {
				// do nothing
			} else if ($mask&_AR_ALLOWHTML) {
				// do nothing - compatibility mode
				/*
				if (is_null( $safeHtmlFilter )) {
					$safeHtmlFilter = new InputFilter( null, null, 1, 1 );
				}
				$arr[$name] = $safeHtmlFilter->process( $arr[$name] );
				*/
			} else {
				// send to inputfilter
				if (is_null( $noHtmlFilter )) {
					$noHtmlFilter = new InputFilter( /* $tags, $attr, $tag_method, $attr_method, $xss_auto */ );
				}
				$return = $noHtmlFilter->process( $return );
			}
			
			// account for magic quotes setting
			if (!get_magic_quotes_gpc()) {
				$return = addslashes( $return );
			}
		}
		
		return $return;
	} else {
		return $def;
	}
}
?>