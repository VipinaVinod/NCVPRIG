<?php
session_start();
error_reporting(0);
include('inputfilter.php');
$code = strtoupper(sanGetParam( $_REQUEST, 'cc', ''));
$random_number = strtoupper(sanGetParam( $_SESSION, 'random_number', ''));
$msg = '';
if ($code  != $random_number)
	echo 'invalid';
?>