<?php 
include('config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title>TNDE</title> 
<meta name="description" content="Registration for NCMST 2022"> 
<meta name="keywords" content="Registration NCMST 2022"> 
<link rel="stylesheet" href="./css/screen.css" media="screen" type="text/css"> 
<link rel="stylesheet" href="./css/jquery.selectBox.css" media="screen" type="text/css">
<script type="text/javascript" src="./javascript/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="./javascript/jquery.elastic.js"></script>
<script type="text/javascript" src="./javascript/init.js"></script>
<script type="text/javascript" src="./javascript/functions.js"></script>
<script type="text/javascript" src="./javascript/form_validation.js"></script>

<style type="text/css">
A:link {font-size:24px;font-weight:700}

A:visited {text-decoration: none}
A:active {text-decoration: none}
A:hover {text-decoration: underline overline; color: red;}
</style>

</head> 
<body>
<div class="wrapper">

	<div class="wrap_cmg">
	
		<div class="page_header">
		
        <br />
<p style="font-size:17px;font-weight:900;color:#600">Workshop on Theory and Numerics of Differential Equations</p>

	  </div>
		<div class="content_cmg">
<?php
$msg = sanGetParam( $_REQUEST, 'msg', '');
if( $msg == 1)
{
	$regno= base64_decode(sanGetParam( $_REQUEST, 'regno', '')) ;
	//$pwd = base64_decode(sanGetParam( $_REQUEST, 'pwd', '')) ; 
?>
<div>
<p align="center" style="border: 5px solid #C03;margin-top:150px">  
<br>	
<span style="font-size:24px; font-weight:bold">Registration ID is <?php echo $regno; ?></span><br><br>
<!--<span style="font-size:24px; font-weight:bold">Password is <?php echo $pwd; ?></span><br><br>
<span style="font-size:24px; font-weight:bold"><a href="login.php">Click here </a> to Pay Registration Fee for completing the registration process </span><br><br>-->

</p>
<p align="left"><a  style="font-weight:bold;font-size:16px" href="<?php echo $homepath;?>"><u>Back</u>
		</a></p>
      
</div>
<?php		
}
else if ($msg == 3)
{
?>
 <div>
<p align="center" style="border: 5px solid #C03;margin-top:150px">  
<br />Email already exists!<br /><br />
</p>
<p align="left"><a  style="font-weight:bold;font-size:16px" href="<?php echo $homepath;?>"><u>Back</u>
		</a></p>
</div>   
<?php	
}
?>
			</div>

		</div>
	</div>
</div>
<div class="footer_cmg">
	<p align="center" style="font-weight:bold;color:#CCC">© Copyright 2023  SSG IIST, Inc. All rights reserved.</p>
</div>
</body></html>