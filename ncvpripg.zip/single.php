<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>TNDE-IIST</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Nunito&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Navbar Start -->
     <div class="container-fluid bg-light position-relative shadow">
    
      <?php include("header.php");?>
    <!-- Detail Start -->
    <div class="container py-1">
        <div class="row pt-1">
            <div class="col-lg-8">
                <div class="d-flex flex-column text-left mb-3">
                    <h4 class="mb-4">About the Workshop:</h4>  
                  
                    <!--<h1 class="mb-3">About the Institute:</h1>
                    <div class="d-flex">
                        <p class="mr-3"><i class="fa fa-user text-primary"></i> Admin</p>
                        <p class="mr-3"><i class="fa fa-folder text-primary"></i> Web Design</p>
                        <p class="mr-3"><i class="fa fa-comments text-primary"></i> 15</p>
                    </div>-->
                </div>
               
                <div class="mb-5">
                 
                    
                    <!--<p>Indian Institute of Space Science and Technology (IIST), situated at Thiruvananthapuram is Deemed to be University under Section 3 of the UGC Act 1956. IIST functions as an autonomous body under the Department of Space, Government of India. The idea of such an institute was mooted keeping in mind the need for high-quality manpower for the Indian space program. The institute is the first of its kind in the country, to offer high-quality education at the undergraduate, graduate, doctoral and post-doctoral levels in areas with a special focus on space sciences, space technology, and space applications. IIST was formally inaugurated on 14 September 2007 by Dr. G. Madhavan Nair, the Chairman of ISRO, and was temporarily housed in the premises of Vikram Sarabhai Space Centre.  Both the founding fathers of the institute, Dr. G Madhavan Nair and Dr. B.N. Suresh, the latter being the first Director of IIST, played a very important role in the formation of the institute, facilitating its establishment and contributing to its vision. Dr. B.N. Suresh piloted the institute from the conception of the idea to its realization in a permanent campus near Thiruvananthapuram in 2010.</p>-->
                    
                    <!--<h2 class="mb-4">About the Department:</h2>
                    <img class="img-fluid rounded w-50 float-left mr-4 mb-3" src="img/blog-111.jpg" alt="Image">
                    <p>IIST was established to foster research oriented toward Space Science and Technology and also to stimulate collaborative research with various units of ISRO and other institutes at a deeper academic level. As part of this initiative, the department of Mathematics offers courses at the undergraduate and graduate level of programs.</p>
                    <p>Department also runs an M.Tech program in Machine Learning and Computing. At present we have 11 faculty members working in various areas of pure as well as applied mathematics including Mathematical Control Theory, Industrial Mathematics, soft computing, Suspension Rheology, Time Series Analysis, Mathematical Elasticity, Homogenization, Partial Differential Equations, Differential Geometry, and its Applications, Stochastic Modeling & Analysis, Queuing Theory, Queuing Network Models, Numerical Solutions to Fluid Dynamics, Numerical Analysis and Singularly Perturbed Differential Equations, Computational Partial Differential Equations, Finite Element Methods, Finite Volume Methods and Discontinuous Galerkin Methods, Commutative Algebra, Machine Learning & Data Mining, Control and Inverse Problems for Deterministic and Stochastic Partial Differential Equations.  The Department is also actively engaged in other activities like organizing training/nurture programs for Mathematics  students as well as seminars/workshops by renowned  scientists from various parts of the world.</p>-->
                    
                    
                    <p align="justify">The study of differential equations is a fundamental subject area of Mathematics that naturally connects pure Mathematics with applied and computational Mathematics and assists in the investigation of various physical model problems. Differential equations provide a natural mathematical description of phenomena in the physical and biological sciences. We intend to rigorously discuss the well-posedness of the solution of ordinary and partial differential equations, as well as stability analysis, during this workshop.  Since finding a closed and analytical solution to differential equations may not always be possible, various numerical techniques for obtaining efficient and robust numerical solutions will also be discussed. MATLAB sessions will also be conducted in the computer lab to have a better understanding of convergence analysis and the employability of the numerical methods. Participants will get an opportunity to interact and exchange ideas with experts on their research problems. Through this workshop, we plan to expose young researchers and faculty members, who are interested in applied and computational mathematics.</p>
                    <p align="justify">Workshop on Theory and Numerics of Differential Equations    (March 16-17, 2023) Sponsored by SERB Project No. CRG/2021/002410 &  Department of Mathematics, IIST Thiruvananthapuram.)
Department of Mathematics.</p></div>

                <!-- Related Post -->
               <!-- <div class="mb-5 mx-n3">
                    <h2 class="mb-4 ml-3">Related Post</h2>
                    <div class="owl-carousel post-carousel position-relative">
                        <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mx-3">
                            <img class="img-fluid" src="img/post-1.jpg" style="width: 80px; height: 80px;">
                            <div class="pl-3">
                                <h5 class="">Theory and Numerics of Differential Equations</h5>
                                <div class="d-flex">
                                    <small class="mr-3"><i class="fa fa-user text-primary"></i> Admin</small>
                                    <small class="mr-3"><i class="fa fa-folder text-primary"></i> Web Design</small>
                                    <small class="mr-3"><i class="fa fa-comments text-primary"></i> 15</small>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mx-3">
                            <img class="img-fluid" src="img/post-2.jpg" style="width: 80px; height: 80px;">
                            <div class="pl-3">
                                <h5 class="">Theory and Numerics of Differential Equations</h5>
                                <div class="d-flex">
                                    <small class="mr-3"><i class="fa fa-user text-primary"></i> Admin</small>
                                    <small class="mr-3"><i class="fa fa-folder text-primary"></i> Web Design</small>
                                    <small class="mr-3"><i class="fa fa-comments text-primary"></i> 15</small>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mx-3">
                            <img class="img-fluid" src="img/post-3.jpg" style="width: 80px; height: 80px;">
                            <div class="pl-3">
                                <h5 class="">Theory and Numerics of Differential Equations</h5>
                                <div class="d-flex">
                                    <small class="mr-3"><i class="fa fa-user text-primary"></i> Admin</small>
                                    <small class="mr-3"><i class="fa fa-folder text-primary"></i> Web Design</small>
                                    <small class="mr-3"><i class="fa fa-comments text-primary"></i> 15</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->

                <!-- Comment List -->
                <!--<div class="mb-5">
                    <h2 class="mb-4">3 Comments</h2>
                    <div class="media mb-4">
                        <img src="img/user.jpg" alt="Image" class="img-fluid rounded-circle mr-3 mt-1" style="width: 45px;">
                        <div class="media-body">
                            <h6>John Doe <small><i>01 Jan 2045 at 12:00pm</i></small></h6>
                            <p>Diam amet duo labore stet elitr ea clita ipsum, tempor labore accusam ipsum et no at. Kasd diam tempor rebum magna dolores sed sed eirmod ipsum. Gubergren clita aliquyam consetetur sadipscing, at tempor amet ipsum diam tempor consetetur at sit.</p>
                            <button class="btn btn-sm btn-light">Reply</button>
                        </div>
                    </div>
                    <div class="media mb-4">
                        <img src="img/user.jpg" alt="Image" class="img-fluid rounded-circle mr-3 mt-1" style="width: 45px;">
                        <div class="media-body">
                            <h6>John Doe <small><i>01 Jan 2045 at 12:00pm</i></small></h6>
                            <p>Diam amet duo labore stet elitr ea clita ipsum, tempor labore accusam ipsum et no at. Kasd diam tempor rebum magna dolores sed sed eirmod ipsum. Gubergren clita aliquyam consetetur sadipscing, at tempor amet ipsum diam tempor consetetur at sit.</p>
                            <button class="btn btn-sm btn-light">Reply</button>
                            <div class="media mt-4">
                                <img src="img/user.jpg" alt="Image" class="img-fluid rounded-circle mr-3 mt-1" style="width: 45px;">
                                <div class="media-body">
                                    <h6>John Doe <small><i>01 Jan 2045 at 12:00pm</i></small></h6>
                                    <p>Diam amet duo labore stet elitr ea clita ipsum, tempor labore accusam ipsum et no at. Kasd diam tempor rebum magna dolores sed sed eirmod ipsum. Gubergren clita aliquyam consetetur, at tempor amet ipsum diam tempor at sit.</p>
                                    <button class="btn btn-sm btn-light">Reply</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->

                <!-- Comment Form -->
                
            </div>

            <div class="col-lg-4 mt-5 mt-lg-0">
                <!-- Author Bio -->
                <!--<div class="d-flex flex-column text-center bg-primary rounded mb-5 py-5 px-4">
                    <img src="img/logo_iist.png" class="img-fluid rounded-circle mx-auto mb-3" style="width: 100px;">
                    <h3 class="text-secondary mb-3">IIST</h3>
                    <p class="text-white m-0">Conset elitr erat vero dolor ipsum et diam, eos dolor lorem ipsum, ipsum ipsum sit no ut est. Guber ea ipsum erat kasd amet est elitr ea sit.</p>
                </div>-->

                <!-- Search Form -->
                <!--<div class="mb-5">
                    <form action="">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-lg" placeholder="Keyword">
                            <div class="input-group-append">
                                <span class="input-group-text bg-transparent text-primary"><i
                                        class="fa fa-search"></i></span>
                            </div>
                        </div>
                    </form>
                </div>-->

                <!-- Category List -->
                <div class="mb-5">
                    <!--<h2 class="mb-4">Categories</h2>-->
                    <!--<ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <a href="">Web Design</a>
                            <span class="badge badge-primary badge-pill">150</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <a href="">Web Development</a>
                            <span class="badge badge-primary badge-pill">131</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <a href="">Online Marketing</a>
                            <span class="badge badge-primary badge-pill">78</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <a href="">Keyword Research</a>
                            <span class="badge badge-primary badge-pill">56</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <a href="">Email Marketing</a>
                            <span class="badge badge-primary badge-pill">98</span>
                        </li>
                    </ul>-->
                </div>

                <!-- Single Image -->
                <!--<div class="mb-5">
                    <img src="img/blog-1e.jpg" alt="" class="img-fluid rounded">
                </div>-->

                <!-- Recent Post -->
                <!--<div class="mb-5">
                    <h2 class="mb-4">Recent Post</h2>
                    <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mb-3">
                        <img class="img-fluid" src="img/post-1.jpg" style="width: 80px; height: 80px;">
                        <div class="pl-3">
                            <h5 class="">Theory and Numerics of Differential Equations</h5>
                            
                        </div>
                    </div>
                    <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mb-3">
                        <img class="img-fluid" src="img/post-2.jpg" style="width: 80px; height: 80px;">
                        <div class="pl-3">
                            <h5 class="">Theory and Numerics of Differential Equations</h5>
                            
                        </div>
                    </div>
                    <div class="d-flex align-items-center bg-light shadow-sm rounded overflow-hidden mb-3">
                        <img class="img-fluid" src="img/post-3.jpg" style="width: 80px; height: 80px;">
                        <div class="pl-3">
                            <h5 class="">Theory and Numerics of Differential Equations</h5>
                            
                        </div>
                    </div>
                </div>-->

                <!-- Single Image -->
                <div class="mb-5">
                    <img src="img/dept.webp" alt="" class="img-fluid rounded">
                </div>

                <!-- Tag Cloud -->
               <!-- <div class="mb-5">
                    <h2 class="mb-4">Tag Cloud</h2>
                    <div class="d-flex flex-wrap m-n1">
                        <a href="" class="btn btn-outline-primary m-1">Design</a>
                        <a href="" class="btn btn-outline-primary m-1">Development</a>
                        <a href="" class="btn btn-outline-primary m-1">Marketing</a>
                        <a href="" class="btn btn-outline-primary m-1">SEO</a>
                        <a href="" class="btn btn-outline-primary m-1">Writing</a>
                        <a href="" class="btn btn-outline-primary m-1">Consulting</a>
                    </div>
                </div>-->

                <!-- Single Image -->
               

                <!-- Plain Text -->
                <!--<div>
                    <h2 class="mb-4">Plain Text</h2>
                    Aliquyam sed lorem stet diam dolor sed ut sit. Ut sanctus erat ea est aliquyam dolor et. Et no consetetur eos labore ea erat voluptua et. Et aliquyam dolore sed erat. Magna sanctus sed eos tempor rebum dolor, tempor takimata clita sit et elitr ut eirmod.
                </div>-->
            </div>
        </div>
    </div>
    <!-- Detail End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-white mt-1 py-1 px-sm-3 px-md-5">
        <div class="row pt-1">
            <!--<div class="col-lg-3 col-md-6 mb-5">
                <a href="" class="navbar-brand font-weight-bold text-primary m-0 mb-4 p-0" style="font-size: 40px; line-height: 40px;">
                    <i class="flaticon-043-teddy-bear"></i>
                    <span class="text-white">KidKinder</span>
                </a>
                <p>Labore dolor amet ipsum ea, erat sit ipsum duo eos. Volup amet ea dolor et magna dolor, elitr rebum duo est sed diam elitr. Stet elitr stet diam duo eos rebum ipsum diam ipsum elitr.</p>
                <div class="d-flex justify-content-start mt-4">
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>-->
            <!--<div class="col-lg-3 col-md-6 mb-5">-->
                <!--<h3 class="text-primary mb-4">Get In Touch</h3>-->
                <!--<div class="d-flex">
                    <h4 class="fa fa-map-marker-alt text-primary"></h4>
                    <div class="pl-3">
                        <h5 class="text-white">Address</h5>
                        <p>123 Street, New York, USA</p>
                    </div>
                </div>-->
               <!-- <div class="d-flex">
                    <h4 class="fa fa-envelope text-primary"></h4>
                    <div class="pl-3">
                        <h5 class="text-white">Email</h5>
                        <p>info@example.com</p>
                    </div>
                </div>-->
                <!--<div class="d-flex">
                    <h4 class="fa fa-phone-alt text-primary"></h4>
                    <div class="pl-3">
                        <h5 class="text-white">Phone</h5>
                        <p>+012 345 67890</p>
                    </div>
                </div>
            </div>-->
            <!--<div class="col-lg-3 col-md-6 mb-5">
                <h3 class="text-primary mb-4">Quick Links</h3>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Home</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>About Us</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Our Classes</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Our Teachers</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right mr-2"></i>Our Blog</a>
                    <a class="text-white" href="#"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                </div>
            </div>-->
            <!--<div class="col-lg-3 col-md-6 mb-5">
                <h3 class="text-primary mb-4">Newsletter</h3>
                <form action="">
                    <div class="form-group">
                        <input type="text" class="form-control border-0 py-4" placeholder="Your Name" required="required" />
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control border-0 py-4" placeholder="Your Email"
                            required="required" />
                    </div>
                    <div>
                        <button class="btn btn-primary btn-block border-0 py-3" type="submit">Submit Now</button>
                    </div>
                </form>
            </div>-->
        </div>
        <div class="container-fluid pt-1" >
            <p class="m-0 text-center text-white">
                &copy;2023 SSG-IIST. All Rights Reserved. 
              
            </p>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary p-3 back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>