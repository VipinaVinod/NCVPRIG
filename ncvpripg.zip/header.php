
<nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0 px-lg-5">
        
        <a href="" class="navbar-brand font-weight-bold text-secondary" style="font-size: 50px;">
          
            <img  src="img/logo_iist.png" alt=""  height="75px" width="75px">
          
          
            <span class="text-primary">IIST</span>
        </a>
        
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav font-weight-bold mx-auto py-0">
                <a href="index.html" class="nav-item nav-link active">Home</a>
                <!--<div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">About</a>
                    <div class="dropdown-menu rounded-0 m-0">
                        <a href="institute.html" class="dropdown-item">About Institute</a>
                        <a href="single.html" class="dropdown-item">About Department</a>
                        <a href="workshop.html" class="dropdown-item">About Workshop</a>
                    </div>
                </div>-->
                <a href="single.php" class="nav-item nav-link">About the Workshop</a>
                <a href="about.php" class="nav-item nav-link">Resource Persons</a>
                <a href="class.php" class="nav-item nav-link">Travel, Food, Boarding and Lodging</a>
                <a href="reg1.php" class="nav-item nav-link">Registration</a>
                <!--<a href="gallery.html" class="nav-item nav-link">Gallery</a>-->
                
                <a href="contact.php" class="nav-item nav-link">Contact</a>
            </div>
           <!-- <a href="" class="btn btn-primary px-4">Join Class</a>-->
        </div>
    </nav>
</div>
<!-- Navbar End -->


<!-- Header Start -->
<div class="container-fluid bg-primary mb-5">
    <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 250px">
    <h3 class="display-3 font-weight-bold text-white">Theory and Numerics of Differential Equations</h3>
    <h4 class="text-white mb-4 mt-5 mt-lg-0">March 16-17, 2023</h4>
        <div class="d-inline-flex text-white">
            <!--<p class="m-0"><a class="text-white" href="index.html">Home</a></p>
            <p class="m-0 px-2">/</p>
            
            <p class="m-0">About the Workshop</p>-->
        </div>
    </div>
</div>
<!-- Header End -->

