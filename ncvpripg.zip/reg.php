<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0046)https://circlesco.com/conference/registration/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
 
<title>NCVPRIPG</title> 
<meta name="description" content="Registration for TNDE"> 
<meta name="keywords" content="Registration TNDE"> 
<?php 
include('config.php');
session_start();
$op = sanGetParam( $_REQUEST, 'opt', ''); 
switch ($op)
{
	case "1":
		saveregister();
		break;	
	default: 
		register();
		break;
}
function saveregister()
{

	global $homepath, $mailhost, $ncmstid,$mailprotocol,$from,$subject;
	$code = strtoupper(sanGetParam( $_REQUEST, 'code', ''));
	$random_number = strtoupper($_SESSION['random_number']);
	//$random_number = strtoupper($_SESSION['code']);
	//echo $code;
	$msg = '';
	$year=date("Y");
	$cat1 = sanGetParam( $_REQUEST, 'cat1', ''); 
	$email_address = sanGetParam( $_REQUEST, 'email_address', ''); 
	$query_email = mysql_query("select Email from tnde where Reg_year='".$year."' and Email= '".$email_address."'");
	$row7 = mysql_fetch_array($query_email);
	$email_verification=$row7['Email'];
	$name = sanGetParam( $_REQUEST, 'name', '');
	$status = sanGetParam( $_REQUEST, 'status', ''); 
	$college = sanGetParam( $_REQUEST, 'college', ''); 
	$gender = sanGetParam( $_REQUEST, 'gender', ''); 
	$Designation = sanGetParam( $_REQUEST, 'desg', ''); 
	$officaladdress = sanGetParam( $_REQUEST, 'officaladdress', ''); 
	$state = sanGetParam( $_REQUEST, 'state', ''); 
	$district = sanGetParam( $_REQUEST, 'dist', ''); 
	
	
	$phone = sanGetParam( $_REQUEST, 'phone', ''); 
	$accomodation = sanGetParam( $_REQUEST, 'accomodation', ''); 
	$arearesearch = sanGetParam( $_REQUEST, 'arearesearch', ''); 
	if($cat1 == 'PhD')
		$arearesearch = sanGetParam( $_REQUEST, 'arearesearch1', ''); 
	//echo "c:".$code ."<br>random:".$random_number;
	//echo $email_address."<br>". $name ."<br>". $status."<br>". $college."<br>". $gender."<br>". $officaladdress."<br>". $phone."<br>". $cat1."<br>". $accomodation;
	//$ins1="INSERT INTO tnde(`Regno`,`Title`,`Name`,`Institute`,`Gender`,`Designation`,`Official_adress`,`Phone_no`,`Email`,`Category1`,`Category2`,`Fee`,`Accomodation_req`,`Food_type`,Area_research,`Reg_year`,User_password,`Remarks`,`Regtime`) VALUES ('".$regno."', '".$status."', '".$name."','".$college."', '".$gender ."','".$Designation ."','".$officaladdress."','".$phone."','".$email_address."','".$cat1."','', '','".$accomodation."','".$arearesearch."','".$year."','".$pwd_no."','',NOW())";	
	
	
	
	//echo $ins1;
		//$query2=mysql_query($ins1);
		//echo $query2."sanjith";

	if($email_verification!='')
	{
	
		?>
		<script>
		window.location.href ='sucess.php?msg=3';	
		</script>
	<?php
	}
	else if ($code  == $code && $email_address != '' && $name !='' && $status!='' && $college!='' && $gender!='' && $officaladdress!='' && $phone!='' && $cat1!='')
	{	
	
		
		$pre_admn=0;
		$row_pers=mysql_query("SELECT MAX(Regno) as m FROM tnde where Reg_year='".$year."' ORDER BY Regno DESC");
		//echo $row_pers;
		$row = mysql_fetch_array($row_pers);
		$prev_admn=$row['m'];
		$key= $prev_admn;
		$pattern = "/(\d+)/";
		$pre_admn = substr($key, -5); 
		if($pre_admn==0)
			$cur_admn="10001";
		else
			 $cur_admn=$pre_admn+1;
		$regno = "TNDE".$year.$cur_admn;
		$pwd_no=uniqid();
				
		$ins1="INSERT INTO tnde(`Regno`,`Title`,`Name`,`Institute`,`Gender`,`Designation`,`Official_adress`,State,District,`Phone_no`,`Email`,`Category1`,`Category2`,`Fee`,`Accomodation_req`,`Food_type`,Area_research,`Reg_year`,User_password,`Remarks`,`Regtime`) VALUES ('".$regno."', '".$status."', '".$name."','".$college."', '".$gender ."','".$Designation ."','".$officaladdress."','".$state."','".$district."','".$phone."','".$email_address."','".$cat1."','', '','".$accomodation."','','".$arearesearch."','".$year."','".$pwd_no."','',NOW())";	//echo $ins1;
		$query2=mysql_query($ins1);
		//echo $query2."sanjith";
		
		if($query2)
		{
			$inss="Your registration for Workshop on Theory and Numerics of Differential Equations -".$year." is confirmed. ";
			$a="Thank you for registering";
			$ii="This is a system generated mail. Please do not reply to this mail. ";
			require_once("phpmailer/class.phpmailer.php");
		
			try 
			{
			//	$body =  "<div class='form_wrap'> ".$inss."<br> Your Registration no is :<b>".$regno."</b><br> Your Password :<b>".$pwd_no."</b><br><b>".$a."</b><br>".$ii." </div>";
			$body =  "<div class='form_wrap'> ".$inss."<br> Your Registration no is :<b>".$regno."</b><br><b>".$a."</b><br>".$ii." </div>";
	
				// Email Part
				$queryemailinfo = mysql_query("select Name,Value from tbl_code where Code='Emailid' ");
				$rowemailinfo = mysql_fetch_array($queryemailinfo);
				$mail = new PHPMailer(true); //New instance, with exceptions enabled
				$mail->SMTPDebug = 0; // 1 used to display SMTP errors and messages, 0 turns off all errors and messages, 2 prints messages only.
				
				$mail->Mailer   = $mailprotocol;  // Alternate is $mail->IsSMTP();
				$mail->SMTPAuth = true;
				$mail->Host       = $mailhost ; // SMTP server 
				$mail->Port       = $port; // set the SMTP server port
				$mail->Username   = $rowemailinfo['Name'];    // SMTP server username
				$mail->Password   = $rowemailinfo['Value'] ;  
				$mail->SMTPDebug = 0; // 1 used to display SMTP errors and messages, 0 turns off all errors and messages, 2 	prints messages only.
				$ncm_stud_id = $email_address;
				$nam = $name;
				$mail->AddAddress($ncmstid , $nam ); // To mail id
				$mail->AddAddress($ncm_stud_id, $nam );
				$mail->From       = 'IIST-TNDE-Workshop';//$sanConfig_domain_name;
				$mail->FromName   = $from ;  
				$mail->Subject    = $subject ;
				$mail->MsgHTML($body);
				$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional
				$mail->WordWrap   = 100; // set word wrap
				$mail->IsHTML(true); 
				if (!$mail->Send()) 
				{
					echo "The email message has NOT been sent for some reason. Please try again later for RegNo. ".$absno;
					echo "Mail Error:" . $mail->ErrorInfo;  //line no 685 that throws exception - class.phpmailer.php
				}
				$mail->ClearAddresses(); // Clear all mail addresses		
				$msg = 'Message has been sent.';	
				
			} 
			catch (phpmailerException $e) 
			{
				$msg = $e->errorMessage();
			}
			echo $msg; 
	?>
			<script>
			window.location.href ='sucess.php?msg=1&regno=<?php echo base64_encode($regno); ?>';	
			</script>
		<?php
		}
	}
	else
	{
		?>
		<p><span style=\"color: RED; font-size: large;
		font-weight: bold;\"><strong><a href="reg.php"><h3 align="left"><em><strong>Back To home</strong></em></h3></a></strong></span></p>
		<div align="center" id="noprint"><font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong>Invalid Inputs!</strong></font></div>
		<?php
	}	
}

function register() 
{ 
global $homepath;
?>
<link rel="stylesheet" href="./css/screen.css" media="screen" type="text/css"> 
<link type='text/css' href='./css/htmlDatePicker.css' rel='stylesheet' media='screen' />
<link rel="stylesheet" href="./css/jquery.selectBox.css" media="screen" type="text/css">
<script type="text/javascript" src="./javascript/htmlDatePicker.js"></script> 
<script type="text/javascript" src="./javascript/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="./javascript/jquery.elastic.js"></script>
<script type="text/javascript" src="./javascript/init.js"></script>
<script type="text/javascript" src="./javascript/form_validation.js"></script>
<script type="text/javascript" src="./javascript/jquery-1.4.3.min.js"></script>

<script type="text/javascript">
	var today = new Date();
	DisablePast = false;
	range_start = new Date(today.getFullYear(),today.getMonth(),8);
	range_end = new Date(today.getFullYear(),today.getMonth(),5);

$(document).ready(function() {
	
	 // refresh captcha
	 $('img#refresh').click(function() {
			change_captcha();
	 });

	 function change_captcha()
	 {
	 	document.getElementById('captcha').src="get_captcha.php?rnd=" + Math.random();
	 }
	 $('#Validation_code').change(function(){
     $.ajax({
	 	type: "POST",
		url: "checkcaptcha.php",
		data: {cc:$(this).val()},
		success: function(dat){
			if(dat == "invalid")
			{
				alert("Invalid captcha, please re-enter!");
				return false;
			}
		}
		});
		});

});	
</script>
<style type="text/css">
<!--
.style1 {font-size: large}
-->
</style>

</head> 
 
<body>

<div class="wrapper">
	<div class="wrap_cmg">
	<div class="page_header">
	<a href="<?php echo $homepath;?>"><h3 align="left"><em><strong>Back To home</strong></em></h3></a><br>
	<h2> NCVPRIPG 2024</h2>
	</div>
	<div class="content_cmg">
<script type="text/javascript">
	
function configureValidation(updatediv)
{

  // set to false if you do not want to disable submit button on failure
  disable_btn_on_submit = false;

  // only update the error_box div on submit
  if (updatediv == 1)
  {
  	initial_submit = true;
  }
  // do not update the error)_box div if initial_submit box
  if (updatediv == 2)
  {
  	if (initial_submit == false)
  	{
  		return true;
  	}
  }
  f = document.forms.register;

  f.status.optional = false;
  f.status.ErrorText = 'Tittle';

  f.name.optional = false;
  f.name.ErrorText = 'Name';

 f.college.optional = false;
  f.college.ErrorText = 'College/Institute';

  f.Designation.optional = false;
  f.Designation.ErrorText = 'Designation';
  f.officaladdress.optional = false;
  f.officaladdress.ErrorText = 'Offical address';
 
  f.phone.optional = false;
  f.phone.ErrorText = 'Phone number'; 
  f.phone.isNumeric=true;
  f.phone.isLengthBetween = [10,12];

  f.email_address.optional = false;
  f.email_address.ErrorText = 'Email';
  f.email_address.isEmail = true;
  
/*  f.ddno.optional = false;
  f.ddno.ErrorText = 'DD no';

  f.bank.optional = false;
  f.bank.ErrorText = 'Name of Bank';*/
  
  f.gender.optional = false;
  f.gender.ErrorText = 'gender';
  f.gender.isCheckedRad=true; 


  f.submit_btn.optional = true;

  var pre_check = null;
  return validateForm(f,pre_check,updatediv);
}
</script>
			<div style="margin-left:18px;font-size:12px">
				<center><p>Registration Form</p></center>
				<small><i>*mandatory fields</i></small>
                
			</div>
			<div class="form_wrap">
                <input type="hidden" name="opt" value="<?php echo 1;?>" />
				<form action="reg.php?opt=1" method="post" name="register" id="register" onsubmit="return configureValidation(1)">
										
					<div class="message alert_message" id="alert_box" style="display:none;"></div>
					
					<div class="message error_message" id="error_box" style="display:none;"></div>
				
					<div class="form_head first">
						<h4>Basic Information</h4>
					</div>
					<div class="form_row">
						<div class="fr_left">
                        	<label for="status" class="required">Title <span>*</span></label><br>
								<select name="status" id="status" onchange="configureValidation(2);" required>
								<option value="" selected="">-- Select One --</option>
								<option value="Prof">Prof</option>
								<option value="Dr">Dr</option>
                                	<option value="Mr">Mr</option>
								<option value="Mrs">Mrs</option>
                                <option value="Ms">Ms</option>
							</select>
						</div>
					
						<div class="push"></div>
					</div>
					<div class="form_row">
						<div class="fr_left">
							<label for="name" class="required">Name (in BLOCK LETTERS)*<span>*</span></label><br>
							<input type="text" name="name" id="name" autocomplete="on" onkeyup="configureValidation(2);" class="input_field" required>
						</div>
						
						<div class="push"></div>
					</div>
					<div class="form_row">
						<label for="college" class="required">Institute/College<span>*</span></label><br>
						<input type="text" name="college" id="college" autocomplete="on" onkeyup="configureValidation(2);" class="input_field" required>
					</div>
					<div class="form_row">
						<div class="fr_left">
                        <br>
                        <label for="gender" class="required">Gender <span>*</span>
                        <input type="radio" name="gender" id="Gender" value="Male" required/><span style="font-size:14px;color:#000;font-weight:100">Male</span>
                        <input type="radio" name="gender" id="Gender" value="Female"/><span style="font-size:14px;color:#000;font-weight:100">Female</span>
						</label><br><br><br>
                        </div> 
                       <!-- <div class="fr_right">
							<label for="Designation" class="required">Designation<span>*</span></label><br>
							<input type="text" name="Designation" id="Designation" autocomplete="on" onkeyup="configureValidation(2);" class="input_field">
					</div>-->
                        	<div class="push"></div>
					</div>
                        <div class="form_row">
                        
                        <div class="fr">
							<label for="officaladdress" class="required">Official address for communication<span>*</span></label><br>
							<textarea name="officaladdress" id="officaladdress" autocomplete="on" class="comments elastic" style="overflow: hidden;" required></textarea><br>
						</div>
                        <div class="push"></div>
                        </div>
                        
					<br><br>
                    	<div class="form_row">
                    <div class="fr_left">
							<label for="phone" class="required">State<span>*</span></label><br>
							<select name="state" id="state" onchange="configureValidation(2);" required>
                            <option>--Select One--</option>
                            <?php 
							$state = "select * from tbl_code where Code='State'";
							$res = mysql_query($state);
							while($row=mysql_fetch_array($res))
							{?>
							
                            
                          <option><?php echo $row['Name'];?></option>
							<?php }
							
							 ?>
                             </select>
                             
						</div>
						<div class="fr_right">
							<label for="email_address" class="required">District <span>*<i id="divEmail" style="display: none;"> Note: Must be an .edu email address</i><i id="divConfirmEmail" style="display: none; color: rgb(17, 190, 8);"> Email Address is valid</i></span></label><br>
							<input type="text" name="dist" id="dist" autocomplete="on" onkeyup="configureValidation(2);" class="input_field"><br>
						
						</div>
						
						<div class="push"></div>
					</div>
                    
                    
                    
                    
                    
                    
                    
                    
					<div class="form_row">
                    <div class="fr_left">
							<label for="phone" class="required">Phone<span>*</span></label><br>
							<input type="tel" name="phone" id="phone" autocomplete="on" onkeyup="configureValidation(2);" class="input_field" required>
						</div>
						<div class="fr_right">
							<label for="email_address" class="required">Email <span>*<i id="divEmail" style="display: none;"> Note: Must be an .edu email address</i><i id="divConfirmEmail" style="display: none; color: rgb(17, 190, 8);"> Email Address is valid</i></span></label><br>
							<input type="email" name="email_address" id="email_address" autocomplete="on" onkeyup="configureValidation(2);" class="input_field"><br>
						
						</div>
						
						<div class="push"></div>
					</div>
					<!--<div class="form_head">
						<h4>Accomodation</h4>
					</div>
					<div class="form_row">
						<div class="fr">
						<input type="radio" name="accomodation" id="acc"  value="Yes"  required/><span style="font-size:14px;color:#000;font-weight:300;margin-right:30px">Yes</span>
                        <input type="radio" name="accomodation" id="acc" value="No" /><span style="font-size:14px;color:#000;font-weight:300;margin-right:30px">No</span>
										

                        </div>
                        <div class="push"></div>
					</div>-->
					<br>
					<script language="javascript">
					$(document).ready(function() {
	$("input[name$='cat1']").click(function() {
        var test = $(this).val();
		$("div.desc").hide();
        $("#"+test).show();
    });
});
					</script>
					
					<div class="form_head">
						<h4>Category</h4>
					</div>
					<div class="form_row">
						<div class="fr">
						<input type="radio" name="cat1" id="cat1"  value="Master Student"  required/><span style="font-size:14px;color:#000;font-weight:300;margin-right:30px">Master Student</span>
                        <input type="radio" name="cat1" id="cat1" value="PhD" /><span style="font-size:14px;color:#000;font-weight:300;margin-right:30px">Ph.D. Student/Research Scholar</span>
						<input type="radio" name="cat1" id="cat1" value="Faculty"/><span style="font-size:14px;color:#000;font-weight:300;margin-right:30px">Faculty/Scientist</span>
						

                        </div>
                        </div>
						<div id="PhD" style="display:none" class="desc">
						<div class="push"></div>
                        <div class="form_head"></div>
                        <div class="form_row">
						<div class="fr">
						<span style="font-size:14px;color:#000;font-weight:300;">Area of Research :</span><input type="text" name="arearesearch1" />
                       
						</div>
						</div>
						</div>
						<div id="Faculty" style="display:none" class="desc">
						<div class="push"></div>
                        <div class="form_head"></div>
                        <div class="form_row">
						<div class="fr">
						<span style="font-size:14px;color:#000;font-weight:300;">Designation :</span> <input type="text" name="desg" />
                        <span style="font-size:14px;color:#000;font-weight:300;margin-left:30px">Area of Research :</span><input type="text" name="arearesearch" />
						</div>
						</div>
						</div>
						<div class="push"></div>
						<div class="form_head"></div>
                        <div class="form_row">
						<div class="fr">
						<table border="0" cellpadding="0" cellspacing="0" width="200" >
						<tr>
						<td width="100" height="34" align="left" bgcolor="#FFFFFF"><img src="get_captcha.php" alt="" name="captcha" id="captcha" /></td>
						<td width="100" align="right" ><img src="images/refresh.jpg" width="40" height="50"  alt="" id="refresh" style="cursor:pointer;" /></td>
						</tr>
						<tr>
						<td height="22" align="left"><input name="code" type="text" id="Validation_code"  autocomplete="off" /></td>
						<td width="48"></td>
						</tr>
						<tr>
						<td></td>
						</tr>
						</table>
						</div>
						<div class="push"></div>						
					</div>


					<div id="divPaymentMethod" style="">
						<div class="submit_row back">
							<input type="submit" name="submit_btn" id="submit_btn" value="Register" class="btn_submit">
						</div>
					</div>


				</form>

			</div>

		</div>
	</div>
</div>
<div class="footer_cmg">
	<p>© Copyright 2023 SSG IIST, Inc. All rights reserved.</p>
</div>
<?php
}
?>
</body></html>