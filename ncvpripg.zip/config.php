<?php
error_reporting(0);
include('inputfilter.php');
$homepath="http://172.20.13.40/ncvpripg";
//Mail 
$homesitepath = "C:\xampp\htdocs\ncvpripg";
$port = "25";	
$mailhost = "mail.iist.ac.in"; // SMTP server
//$ncmstid='ncmst2022@iist.ac.in';
$ncmstid='sanjithrs@gmail.com';
$mailprotocol = "smtp";
$from = "IIST";
$subject = "IIST Workshop Registration";
$subject1 = "Workshop  Abstract Registration";

//$host="172.20.0.213:3306";
//$username="2013user";  
//$password="2013user"; 
$host="localhost";
$username="root";  
$password=""; 
$db_name="db_conference";  
$con = mysql_connect("$host", "$username", "$password");
if(! $con)
{
	die('Connection Failed'.mysql_error());
}
mysql_select_db($db_name,$con);
?>